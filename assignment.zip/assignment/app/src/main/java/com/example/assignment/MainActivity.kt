package com.example.assignment

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Declare all UI elements
    lateinit var etName: EditText
    lateinit var etEmail: EditText
    lateinit var etAge: EditText
    lateinit var etBiography: EditText
    lateinit var rgColour: RadioGroup
    lateinit var btnSave: Button

    // Declare SharedPreferences
    lateinit var sharedPreferences: SharedPreferences

    // Key constants — prevents typo bugs
    companion object {
        const val PREFS_NAME   = "UserProfilePrefs"
        const val KEY_NAME     = "key_name"
        const val KEY_EMAIL    = "key_email"
        const val KEY_AGE      = "key_age"
        const val KEY_COLOUR   = "key_colour"
        const val KEY_BIO      = "key_biography"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Link UI elements to their XML IDs
        etName      = findViewById(R.id.etName)
        etEmail     = findViewById(R.id.etEmail)
        etAge       = findViewById(R.id.etAge)
        etBiography = findViewById(R.id.etBiography)
        rgColour    = findViewById(R.id.rgColour)
        btnSave     = findViewById(R.id.btnSave)

        // Save button click — saves all fields manually
        btnSave.setOnClickListener {
            saveData()
            Toast.makeText(this, "Profile Saved!", Toast.LENGTH_SHORT).show()
        }
    }

    // Called every time the app comes to the foreground — RESTORES data
    override fun onResume() {
        super.onResume()
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        // Retrieve saved values (defaults shown if nothing saved yet)
        etName.setText(sharedPreferences.getString(KEY_NAME, ""))
        etEmail.setText(sharedPreferences.getString(KEY_EMAIL, ""))
        etAge.setText(sharedPreferences.getString(KEY_AGE, ""))
        etBiography.setText(sharedPreferences.getString(KEY_BIO, ""))

        // Restore RadioGroup selection
        val savedColourId = sharedPreferences.getInt(KEY_COLOUR, -1)
        if (savedColourId != -1) {
            rgColour.check(savedColourId)
        }
    }

    // Called every time the app goes to the background — SAVES data automatically
    override fun onPause() {
        super.onPause()
        saveData()
    }

    // Reusable save function
    private fun saveData() {
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        editor.putString(KEY_NAME,  etName.text.toString())
        editor.putString(KEY_EMAIL, etEmail.text.toString())
        editor.putString(KEY_AGE,   etAge.text.toString())
        editor.putString(KEY_BIO,   etBiography.text.toString())
        editor.putInt(KEY_COLOUR,   rgColour.checkedRadioButtonId)

        editor.apply() // Save asynchronously (recommended)
    }
}